---
name: ai-digital-human-modeling
description: 统筹从参考或现有模型制作可编辑三维数字人，或处理跨造型、绑定、动作、私人助理及交付的改版。用于定义母本、目标格式、分工和验收；单项修补可直接进入对应分技能。
---

# AI 数字人建模

先核对用途、输入和最终入口。记录实际加载的母本、原图与确认设计、可改和锁定区域、授权用途、要交付的源文件与运行格式。用户新指定的唯一参考优先，原图约束可见区域，生成补视图只承担设计补全。局部修改只从授权范围内的同版母本派生候选。活跃 App 与项目母本按项目自己的发布规则管理。

## 选择分技能

| 需要解决的问题 | 使用 | 交给下一步的结果 |
| --- | --- | --- |
| 长相、头身、发丝、皮肤、服装、局部网格或饰品 | [角色造型](subskills/digital-human-appearance/SKILL.md) | 可编辑静帧、造型对照、锁定范围 |
| 骨架、控制器、换绑、蒙皮和服装跟随 | [骨骼与蒙皮](subskills/digital-human-rigging/SKILL.md) | 已绑定母本、骨骼与形变合同、压力姿势证据 |
| 3D 动作、手势、脸部表情、动作重定向、剪辑与轮播 | [动作与表情](subskills/digital-human-emotion-motion/SKILL.md) | 片段清单、各片段可抢占条件和实际播放证据 |
| 声线、人设、唤醒与原生会话接入 | [私人助理角色](subskills/private-assistant-character/SKILL.md) | 接收片段清单，接通声线、人设和宿主端状态并验证组合 |
| FBX/GLB 回读、引擎或网页加载、实模录屏与发布 | [导出与展示](subskills/digital-human-delivery/SKILL.md) | 同版导出、回读、运行或上线证据 |

按实际范围读相应分技能。单图驱动的人像视频走可用的 LivePortrait 或其他口播流程。仅要求二维视频时，按身份稳定性、连续表演及所需音画同步验收；要可编辑网格、蒙皮或多角度交互时才走三维建模。蓝宝等已有宿主按专用角色合同工作，通用方法在需要时调用分技能。

声线、人设和动作同时接入时，用[原生会话交接](subskills/private-assistant-character/references/integration.md#原生会话交接)把片段清单、宿主状态和组合验收连起来。单改其中一项时，从已验收的母本与接口开始，只复验受影响的交接。

## 母本与交付合同

| 人物类型 | 本路线默认格式 | 源文件 |
| --- | --- | --- |
| 可识别真人数字人 | `FBX` | 可编辑 Blender 工程，涉及真人先核用途和授权 |
| 动漫/虚构角色 | `GLB` | 可编辑 Blender 工程，可由多视图形状候选开始 |

真人为 FBX，动漫/虚构人物为 GLB，是当前默认交付约定。用户指定格式与宿主能力优先。原生发丝及控制器另保留编辑源。详细制作与回退证据见 [可编辑网格](references/editable-character-route.md)、[授权与隐私](references/licensing-and-privacy.md) 和 [验证门](references/validation-gates.md)。

### 先静帧，后骨骼和动作

整条路线依次冻结认可的静帧、绑定合同、动作版本和同版导出。已有可用母本时从需求所处步骤开始。每次外形或绑定变更回归受影响的旧姿势，播放镜头及目标运行端按本次交付范围验收。目标 FBX/GLB 在空场景重导入，检查网格、材质、骨架、权重与实际片段。

视觉门与数值门彼此独立。记录 `user_acceptance`、`technical_checks` 和 `remaining_issues`。未闭合候选为 `PARTIAL`；身份或交付硬门失败为 `NO-SHIP`。将录屏、正式部署和本人验收关联到对应构建。

## 经验回写

把可复用的做法写入对应分技能，保留前提、失败反例和验证范围。项目版本、人物参考、声源、运行资产和配置按项目保存。美杜莎和菲菲的公开视频及制作经验见 [私人助理案例](subskills/private-assistant-character/references/case-evidence.md)。
